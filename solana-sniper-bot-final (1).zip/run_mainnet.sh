#!/bin/bash
cargo run --release
